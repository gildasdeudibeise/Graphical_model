##	Load necessary packages and data
#Let load necessary packages and dataset to use
rm(list=ls())
library(igraph)
library(data.table)
library(dplyr)
library(Hmisc)
library(bnlearn)
library(Rgraphviz)
library(qgraph)

data_stock = fread("/Users/deudibegildas/Downloads/SP500_stock_prices.csv")
data_stock2 = data_stock[ , colSums(is.na(data_stock)) == 0]
data_stock3 = t(na.omit(t(data_stock)))
data_stock4 = as.data.frame(t(na.omit(t(data_stock))))


# Compute correlations:
CorMat <- cor_auto(data_stock4[,2:40])

# Compute graph with tuning = 0 (BIC):
BICgraph <- EBICglasso(CorMat, nrow(data_stock), 0, threshold = TRUE)

# Compute graph with tuning = 0.5 (EBIC)
EBICgraph <- EBICglasso(CorMat, nrow(data_stock), 0.5, threshold = TRUE)

# Compute graph with tuning = 0 (BIC):
BICgraph <- EBICglasso(CorMat, nrow(data_stock), 0, threshold = TRUE)

# Compute graph with tuning = 0.5 (EBIC)
EBICgraph <- EBICglasso(CorMat, nrow(data_stock), 0.5, threshold = TRUE)

# Plot both:
layout(t(1:2))
BICgraph <- qgraph(BICgraph, layout = "spring", title = "Fig 1.a. 
                   Plot of model graph based on BIC criterion", 
                   title.cex =0.7, details = TRUE)
EBICgraph <- qgraph(EBICgraph, layout = "spring", title = 
                      "Fig 1.b. Plot of model graph based on 
                    EBIC criterion", title.cex =0.7)

indicators = as.data.frame(centralityTable(list(BIC = BICgraph, 
                                                EBIC = EBICgraph)))
Strength_BIC= indicators[indicators$measure == 'Strength' & 
                           indicators$type=='BIC',]
Strength_EBIC= indicators[indicators$measure == 'Strength' 
                          & indicators$type=='EBIC',]
df_BIC_s <- Strength_BIC[order(Strength_BIC$value,decreasing = TRUE),]
df_EBIC_s <- Strength_EBIC[order(Strength_BIC$value,decreasing = TRUE),]
#par(mfrow=c(2, 1))
#barplot(df_BIC_s$value,names.arg = df_BIC_s$node, cex.names=0.7, las=2, main = "Strength using BIC criteria", font.main = 4)
barplot(df_EBIC_s$value,names.arg = df_BIC_s$node, cex.names=0.7, las=2,
        main = "Fig 2.a. Strength using EBIC criteria", font.main = 1)

indicators = as.data.frame(centralityTable(list(BIC = BICgraph, 
                                                EBIC = EBICgraph)))
betweenness_BIC= indicators[indicators$measure == 'Betweenness' & 
                              indicators$type=='BIC',]
betweenness_EBIC= indicators[indicators$measure == 'Betweenness' & 
                               indicators$type=='EBIC',]
df_BIC_b <- betweenness_BIC[order(betweenness_BIC$value,decreasing = TRUE),]
df_EBIC_b <- betweenness_EBIC[order(betweenness_BIC$value,decreasing = TRUE),]
#par(mfrow=c(2, 1))
#barplot(df_BIC_b$value,names.arg = df_BIC_b$node, cex.names=0.7, las=2, main = "betweenness using BIC criteria", font.main = 4)
barplot(df_EBIC_b$value,names.arg = df_BIC_b$node, cex.names=0.7, las=2, 
        main = "Fig 2.b. betweenness using EBIC criteria", font.main = 1)


indicators = as.data.frame(centralityTable(list(BIC = BICgraph, 
                                                EBIC = EBICgraph)))
Closeness_BIC= indicators[indicators$measure == 'Closeness' & 
                            indicators$type=='BIC',]
Closeness_EBIC= indicators[indicators$measure == 'Closeness' & 
                             indicators$type=='EBIC',]
df_BIC_c <- Closeness_BIC[order(Closeness_BIC$value,decreasing = TRUE),]
df_EBIC_c <- Closeness_EBIC[order(Closeness_BIC$value,decreasing = TRUE),]
#par(mfrow=c(2, 1))
#barplot(df_BIC_c$value,names.arg = df_BIC_c$node, cex.names=0.7, las=2, main = "Closeness using BIC criteria", font.main = 4)
barplot(df_EBIC_c$value,names.arg = df_BIC_c$node, cex.names=0.7, las=2, 
        main = "Fig 2.c. Closeness using EBIC criteria", font.main = 1)

indicators = as.data.frame(centralityTable(list(BIC = BICgraph, 
                                                EBIC = EBICgraph)))
ExpectedInfluence_BIC= indicators[indicators$measure == 'ExpectedInfluence' 
                                  & indicators$type=='BIC',]
ExpectedInfluence_EBIC= indicators[indicators$measure == 'ExpectedInfluence' 
                                   & indicators$type=='EBIC',]
df_BIC_e <- ExpectedInfluence_BIC[order(ExpectedInfluence_BIC$value,decreasing = TRUE),]
df_EBIC_e <- ExpectedInfluence_EBIC[order(ExpectedInfluence_BIC$value,decreasing = TRUE),]
#par(mfrow=c(2, 1))
#barplot(df_BIC_e$value,names.arg = df_BIC_e$node, cex.names=0.7, las=2, main = "ExpectedInfluence using BIC criteria", font.main = 4)
barplot(df_EBIC_e$value,names.arg = df_BIC_e$node, cex.names=0.7, las=2, 
        main = "Fig 2.d. ExpectedInfluence using EBIC criteria", font.main = 1)


# Compute all centrality indicators
centralityPlot(list(BIC = BICgraph, EBIC = EBICgraph), include = "all", 
               orderBy = "ExpectedInfluence")

# centralityPlot(list(BIC = BICgraph, EBIC = EBICgraph))
clusteringPlot(list(BIC = BICgraph, EBIC = EBICgraph))



centralityTable(list(BIC = BICgraph, EBIC = EBICgraph))
clusteringTable(list(BIC = BICgraph, EBIC = EBICgraph))







