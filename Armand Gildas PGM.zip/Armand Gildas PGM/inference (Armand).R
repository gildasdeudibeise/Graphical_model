rm(list=ls())

# import dependencies

library(readr)
library(igraph)
library(sand)
library(tidyr)

# load dataset and remove NA

trainData = read_csv("PGM/train_df.csv")
trainData = trainData[,2:ncol(trainData)]
trainData = trainData[,colSums(is.na(trainData))==0]
colnames(trainData) = sapply(colnames(trainData),function(x) gsub('-','',x))

testData = read_csv("PGM/test_df.csv")
testData = testData[,2:ncol(testData)]
testData = testData[,colSums(is.na(testData))==0]
colnames(testData) = sapply(colnames(testData),function(x) gsub('-','',x))

# partial correlation

corr_matrix = cor(trainData[,2:ncol(trainData)])

adj_mat = function(corrMatrix, p_threshold = 0.05) {
  
  pvals_matrix=matrix(0,dim(corrMatrix)[1],dim(corrMatrix)[2])
  
  for (i in seq(1,dim(corrMatrix)[1])){
    for (j in seq(1,dim(corrMatrix)[2])){
      rowi=corrMatrix[i,-c(i,j)]
      rowj=corrMatrix[j,-c(i,j)]
      tmp=(corrMatrix[i,j]-rowi*rowj)/sqrt((1-rowi^2)*(1-rowj^2))
      tmp.zvals=0.5*log((1+tmp)/(1-tmp))
      tmp.s.zvals=sqrt(dim(trainData)[1]-4)*tmp.zvals
      tmp.pvals=2*pnorm(abs(tmp.s.zvals),0,1,lower.tail=FALSE)
      pvals_matrix[i,j]=max(tmp.pvals)
    }	
  }
  
  adjPvals_vec=p.adjust(pvals_matrix[lower.tri(pvals_matrix)], "BH")
  edges_vec=adjPvals_vec<p_threshold

  pcorr.A = matrix(0,dim(corrMatrix)[1],dim(corrMatrix)[2])
  pcorr.A[lower.tri(pcorr.A)] = as.numeric(edges_vec)
  
  return(pcorr.A)	
}

adj_matrix = adj_mat(corr_matrix)
adj_matrix = `colnames<-`(adj_matrix,colnames(trainData)[2:length(colnames(trainData))])
adj_matrix = `rownames<-`(adj_matrix,colnames(trainData)[2:length(colnames(trainData))])

# plot undirected graph

graph = graph.adjacency(adj_matrix,"undirected")
plot(graph,vertex.size=3,vertex.color="lightblue")

# function to select a stock's neighbors

select_ne = function(ticker,adj_matrix, graph) {
  ne_list = colnames(adj_matrix)[as.numeric(neighbors(graph,as.character(ticker)))]
}

MSFT = select_ne('MSFT',adj_matrix, graph)

# function to plot subgraph of stock's neighbors

plot_subgraph = function(ticker,graph) {
  plot(induced_subgraph(graph,unlist(ego(graph, order=1, nodes = as.character(ticker), mode = "all", mindist = 0))))
}

plot_subgraph('MSFT',graph)

# example for MSFT

training_MSFT = trainData[,c('MSFT',MSFT)]
plot.ts(training_MSFT[,1:10])

# function to predict price day before

predict_yesterday = function(ticker,cov_list,training_data,test_data) {
  
  covariate_list = intersect(cov_list,colnames(training_data))
  covariate_list = intersect(covariate_list,colnames(test_data))
  
  training = training_data[,c(ticker,covariate_list)]
  test = test_data[nrow(test_data),c(ticker,covariate_list)]
  
  model = lm(as.formula(paste0(ticker,'~.')),training)
  prediction = predict(model,test[,2:ncol(test)])
  
  return(as.numeric(prediction))
  
}

# make predictions

predictions = c()
for (ticker in 2:length(colnames(testData))) {
  print(ticker)
  neighbors = select_ne(colnames(testData)[ticker],adj_matrix,graph)
  predictions[ticker-1] = predict_yesterday(colnames(testData)[ticker],
                                          neighbors,
                                          trainData,
                                          testData)
  
}

# find and plot residuals

resid_pctg = as.numeric((predictions - testData[nrow(testData),2:ncol(testData)])/testData[nrow(testData),2:ncol(testData)])
hist(resid_pctg,breaks = 100)
mean_error = sum(abs(resid_pctg))/length(predictions)
stDev_error = sd(resid_pctg)

# outlier analysis

which.max(resid_pctg)
max(resid_pctg)
colnames(testData)[233] # Enphase Energy

resid_df = data.frame(resid_pctg)
colnames(testData[67]) # Tesla
colnames(testData[265]) # ALbemarle

plot(trainData$Date,trainData$ENPH,type='l',main='Enphase Energy')
plot(trainData$Date,trainData$TSLA,type='l',main='Tesla')
plot(trainData$Date,trainData$ALB,type='l',main='Albemarle Corporation')

# with short window

trainData = read_csv("PGM/train_df.csv")
trainData = trainData[1:300,2:ncol(trainData)]
trainData = trainData[,colSums(is.na(trainData))==0]
colnames(trainData) = sapply(colnames(trainData),function(x) gsub('-','',x))

corr_matrix = cor(trainData[,2:ncol(trainData)])
adj_matrix = adj_mat(corr_matrix)
adj_matrix = `colnames<-`(adj_matrix,colnames(trainData)[2:length(colnames(trainData))])
adj_matrix = `rownames<-`(adj_matrix,colnames(trainData)[2:length(colnames(trainData))])
graph = graph.adjacency(adj_matrix,"undirected")

predictions = c()
for (ticker in 2:length(colnames(testData))) {
  print(ticker)
  neighbors = select_ne(colnames(testData)[ticker],adj_matrix,graph)
  predictions[ticker-1] = predict_yesterday(colnames(testData)[ticker],
                                            neighbors,
                                            trainData,
                                            testData)
  
}

resid_pctg = as.numeric((predictions - testData[nrow(testData),2:ncol(testData)])/testData[nrow(testData),2:ncol(testData)])
hist(resid_pctg,breaks = 100)
mean_error = sum(abs(resid_pctg))/length(predictions)
stDev_error = sd(resid_pctg)

# tune p-value

adj_matrix2 = adj_mat(corr_matrix,p_threshold = .75)
adj_matrix2 = `colnames<-`(adj_matrix2,colnames(trainData)[2:length(colnames(trainData))])
adj_matrix2 = `rownames<-`(adj_matrix2,colnames(trainData)[2:length(colnames(trainData))])
graph2 = graph.adjacency(adj_matrix2,"undirected")

predictions = c()
for (ticker in 2:length(colnames(testData))) {
  print(ticker)
  neighbors = select_ne(colnames(testData)[ticker],adj_matrix2,graph2)
  predictions[ticker-1] = predict_yesterday(colnames(testData)[ticker],
                                            neighbors,
                                            trainData,
                                            testData)
  
}

resid_pctg = as.numeric((predictions - testData[nrow(testData),2:ncol(testData)])/testData[nrow(testData),2:ncol(testData)])
hist(resid_pctg,breaks = 100)
mean_error = sum(abs(resid_pctg))/length(predictions)
stDev_error = sd(resid_pctg)