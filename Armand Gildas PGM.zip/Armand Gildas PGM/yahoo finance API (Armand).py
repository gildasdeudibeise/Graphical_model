#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  8 13:27:01 2023

@author: ensai
"""

import pandas as pd
import yfinance as yf

companies = pd.read_csv('PGM/archive/sp500_companies.csv')['Symbol'].to_list()

price_data_df = pd.DataFrame()
for ticker in companies[0:len(companies)]:
    stock = yf.download(str(ticker))['Adj Close']
    price_data_df = pd.concat([price_data_df,stock],axis=1)

price_data_df.reset_index(inplace = True)
price_data_df.columns = ['Date',*companies]
price_data_df.sort_values(by='Date', inplace = True)


train_mask = (price_data_df['Date'] >= '2020-01-01')
train_data = price_data_df.loc[train_mask]
test_mask = ('2017-01-01'<= price_data_df['Date'] <= '2020-01-01')
test_data = price_data_df.loc[test_mask]

train_data.to_csv('PGM/train_df.csv')
test_data.to_csv('PGM/test_df.csv')